<?php
//Old is Gold. East and west PHP is the best. F**k you other stac. 