## Condosale API Integration 
- Find Condosale API key and ID. 
- Submit gravity form field id and save.
- Boom Easy to integrate API's.

  
![User Interface](https://github.com/Oleraj09/CRM/blob/master/assets/images/screencapture-localhost-OlerajMondol-plugin-wp-admin-admin-php-2024-08-05-03_43_24.png)
